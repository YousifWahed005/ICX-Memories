import type { FrameType } from "@/lib/types";

const FRAME_CYCLE: FrameType[] = [
  "polaroid",
  "taped",
  "rotated-card",
  "polaroid",
  "torn-paper",
  "taped",
];

/**
 * Deterministic-but-varied auto-layout: given how many photos already
 * exist in a collection, produce the next frame type + rotation so new
 * uploads slot in looking intentional without any manual placement.
 */
export function nextAutoLayout(existingCount: number): {
  frame_type: FrameType;
  rotation: number;
} {
  const frame_type = FRAME_CYCLE[existingCount % FRAME_CYCLE.length];
  // Pseudo-random but stable rotation derived from index, spread -6..6deg
  const seed = (existingCount * 37) % 12;
  const rotation = seed - 6;
  return { frame_type, rotation };
}

/** Span classes for the editorial collage grid, cycles for visual rhythm. */
const SPAN_CYCLE = [
  "col-span-2 row-span-2",
  "col-span-1 row-span-1",
  "col-span-1 row-span-2",
  "col-span-2 row-span-1",
  "col-span-1 row-span-1",
  "col-span-1 row-span-2",
  "col-span-2 row-span-2",
  "col-span-1 row-span-1",
];

export function spanForIndex(index: number): string {
  return SPAN_CYCLE[index % SPAN_CYCLE.length];
}
