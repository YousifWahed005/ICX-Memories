import { createClient } from "@/lib/supabase/server";
import type { EPProfile, EPWithPhotos, GeneralMemory } from "@/lib/types";

export async function getAllEPs(): Promise<EPProfile[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("ep_profiles")
    .select("*")
    .order("joined_date", { ascending: true });
  if (error) {
    console.error(error);
    return [];
  }
  return data as EPProfile[];
}

export async function getEPWithPhotos(id: string): Promise<EPWithPhotos | null> {
  const supabase = await createClient();
  const { data: ep, error } = await supabase
    .from("ep_profiles")
    .select("*")
    .eq("id", id)
    .single();
  if (error || !ep) return null;

  const { data: photos } = await supabase
    .from("ep_photos")
    .select("*")
    .eq("ep_id", id)
    .order("sort_order", { ascending: true });

  return { ...(ep as EPProfile), photos: photos || [] };
}

export async function getGeneralMemories(): Promise<GeneralMemory[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("general_memories")
    .select("*")
    .order("sort_order", { ascending: true });
  if (error) {
    console.error(error);
    return [];
  }
  return data as GeneralMemory[];
}
