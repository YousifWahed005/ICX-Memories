export type FrameType =
  | "polaroid"
  | "taped"
  | "rotated-card"
  | "envelope"
  | "filmstrip"
  | "torn-paper";

export interface EPProfile {
  id: string;
  name: string;
  country: string;
  profile_image: string;
  joined_date: string; // ISO date
  left_date: string; // ISO date
  theme_color: string; // hex
  created_at: string;
  updated_at: string;
}

export interface EPPhoto {
  id: string;
  ep_id: string;
  image_url: string;
  caption: string | null;
  photo_date: string | null;
  sort_order: number;
  frame_type: FrameType;
  rotation: number;
  created_at: string;
}

export interface GeneralMemory {
  id: string;
  image_url: string;
  caption: string | null;
  photo_date: string | null;
  sort_order: number;
  frame_type: FrameType;
  rotation: number;
  featured: boolean;
  created_at: string;
}

export interface EPWithPhotos extends EPProfile {
  photos: EPPhoto[];
}
