"use client";

import PhotoFrame from "./PhotoFrame";
import { useMemoryTransition } from "./TransitionProvider";
import type { EPProfile, FrameType } from "@/lib/types";
import { motion } from "framer-motion";

const FRAME_ROTATION: { frame: FrameType; rotation: number }[] = [
  { frame: "polaroid", rotation: -4 },
  { frame: "taped", rotation: 3 },
  { frame: "rotated-card", rotation: -2 },
  { frame: "torn-paper", rotation: 5 },
  { frame: "envelope", rotation: -3 },
];

export default function EPCard({ ep, index }: { ep: EPProfile; index: number }) {
  const { openMemory } = useMemoryTransition();
  const variant = FRAME_ROTATION[index % FRAME_ROTATION.length];

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.6, delay: (index % 6) * 0.06 }}
      className="w-full max-w-[220px]"
    >
      <PhotoFrame
        src={ep.profile_image}
        alt={`${ep.name} — ${ep.country}`}
        caption={ep.name}
        date={ep.joined_date}
        frameType={variant.frame}
        rotation={variant.rotation}
        accent={ep.theme_color}
        onClick={() =>
          openMemory(`/ep/${ep.id}`, ep.profile_image, ep.theme_color)
        }
      />
      <p className="text-center font-hand text-base text-[color:var(--color-ink)]/60 mt-1">
        {ep.country}
      </p>
    </motion.div>
  );
}
