export default function Footer() {
  return (
    <footer className="relative z-10 py-10 text-center">
      <p className="font-hand text-lg text-[color:var(--color-ink)]/40">
        Made by your fav askimm: Tito
      </p>
    </footer>
  );
}
