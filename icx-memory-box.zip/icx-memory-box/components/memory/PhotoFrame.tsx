"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { useState } from "react";
import type { FrameType } from "@/lib/types";
import clsx from "clsx";

interface PhotoFrameProps {
  src: string;
  alt: string;
  caption?: string | null;
  date?: string | null;
  frameType?: FrameType;
  rotation?: number;
  className?: string;
  sizes?: string;
  priority?: boolean;
  onClick?: () => void;
  accent?: string;
  idle?: boolean;
}

function formatDate(d?: string | null) {
  if (!d) return "";
  try {
    return new Date(d).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  } catch {
    return d;
  }
}

export default function PhotoFrame({
  src,
  alt,
  caption,
  date,
  frameType = "polaroid",
  rotation = 0,
  className,
  sizes = "(max-width: 768px) 90vw, 400px",
  priority = false,
  onClick,
  accent = "var(--color-accent-warm)",
  idle = true,
}: PhotoFrameProps) {
  const [loaded, setLoaded] = useState(false);

  const idleAnim = idle
    ? {
        y: [0, -3, 0],
        rotate: [rotation, rotation + (rotation >= 0 ? 0.6 : -0.6), rotation],
      }
    : {};

  return (
    <motion.button
      type="button"
      onClick={onClick}
      initial={{ rotate: rotation, opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      animate={idle ? idleAnim : { rotate: rotation }}
      transition={
        idle
          ? { duration: 5 + (rotation % 3), repeat: Infinity, ease: "easeInOut" }
          : { type: "spring", stiffness: 200, damping: 20 }
      }
      whileHover={{
        rotate: 0,
        scale: 1.05,
        zIndex: 30,
        transition: { type: "spring", stiffness: 300, damping: 18 },
      }}
      whileTap={{ scale: 0.98 }}
      className={clsx(
        "group relative block text-left cursor-pointer select-none",
        "focus-visible:outline-none",
        className
      )}
      style={{ transformOrigin: "center" }}
      aria-label={alt}
    >
      {frameType === "polaroid" && (
        <div className="bg-[#fdfaf4] p-[10px] pb-[34px] shadow-[0_8px_20px_rgba(43,38,32,0.18)] rounded-[2px]">
          <div className="relative w-full aspect-[4/5] overflow-hidden bg-[#e5ddcd]">
            <Image
              src={src}
              alt={alt}
              fill
              sizes={sizes}
              priority={priority}
              onLoad={() => setLoaded(true)}
              className={clsx(
                "object-cover transition-all duration-700",
                loaded ? "blur-0 scale-100" : "blur-md scale-105"
              )}
            />
          </div>
          {caption && (
            <p className="font-hand text-[#4a4238] text-lg mt-2 leading-none truncate">
              {caption}
            </p>
          )}
          {date && (
            <p className="font-hand text-[#8a8072] text-sm leading-none mt-0.5">
              {formatDate(date)}
            </p>
          )}
        </div>
      )}

      {frameType === "taped" && (
        <div className="relative bg-[#fdfaf4] p-2 shadow-[0_10px_24px_rgba(43,38,32,0.2)]">
          <span
            className="tape w-16 h-6 -top-3 left-1/2 -translate-x-1/2 rotate-[-3deg]"
            aria-hidden
          />
          <div className="relative w-full aspect-[5/4] overflow-hidden">
            <Image
              src={src}
              alt={alt}
              fill
              sizes={sizes}
              priority={priority}
              onLoad={() => setLoaded(true)}
              className={clsx(
                "object-cover transition-all duration-700",
                loaded ? "blur-0 scale-100" : "blur-md scale-105"
              )}
            />
          </div>
          {caption && (
            <p className="font-hand text-[#4a4238] text-base mt-1.5 px-1 truncate">
              {caption}
            </p>
          )}
        </div>
      )}

      {frameType === "rotated-card" && (
        <div className="relative bg-white p-[6px] shadow-[0_6px_16px_rgba(43,38,32,0.16)] rounded-sm">
          <div className="relative w-full aspect-square overflow-hidden rounded-sm">
            <Image
              src={src}
              alt={alt}
              fill
              sizes={sizes}
              priority={priority}
              onLoad={() => setLoaded(true)}
              className={clsx(
                "object-cover transition-all duration-700",
                loaded ? "blur-0 scale-100" : "blur-md scale-105"
              )}
            />
            <div
              className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-3"
              style={{
                background:
                  "linear-gradient(to top, rgba(0,0,0,0.55), transparent 60%)",
              }}
            >
              {caption && (
                <span className="font-hand text-white text-base leading-none">
                  {caption}
                </span>
              )}
            </div>
          </div>
        </div>
      )}

      {frameType === "envelope" && (
        <div
          className="relative shadow-[0_10px_24px_rgba(43,38,32,0.2)] rounded-[2px] overflow-hidden"
          style={{ background: accent }}
        >
          <div className="relative w-full aspect-[4/5]">
            <Image
              src={src}
              alt={alt}
              fill
              sizes={sizes}
              priority={priority}
              onLoad={() => setLoaded(true)}
              className={clsx(
                "object-cover mix-blend-luminosity opacity-90 transition-all duration-700",
                loaded ? "blur-0 scale-100" : "blur-md scale-105"
              )}
            />
            <div
              className="absolute inset-0"
              style={{
                clipPath: "polygon(0 0, 50% 45%, 100% 0)",
                background: "rgba(247,241,232,0.9)",
              }}
            />
            {caption && (
              <span className="absolute bottom-2 left-2 font-hand text-[#fdfaf4] text-base drop-shadow">
                {caption}
              </span>
            )}
          </div>
        </div>
      )}

      {frameType === "filmstrip" && (
        <div className="relative bg-[#22201c] p-2 shadow-[0_10px_24px_rgba(43,38,32,0.25)]">
          <div className="flex gap-1 mb-1">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="w-1.5 h-1.5 bg-[#0f0e0c] rounded-[1px]" />
            ))}
          </div>
          <div className="relative w-full aspect-[4/3] overflow-hidden">
            <Image
              src={src}
              alt={alt}
              fill
              sizes={sizes}
              priority={priority}
              onLoad={() => setLoaded(true)}
              className={clsx(
                "object-cover transition-all duration-700",
                loaded ? "blur-0 scale-100" : "blur-md scale-105"
              )}
            />
          </div>
          <div className="flex gap-1 mt-1">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="w-1.5 h-1.5 bg-[#0f0e0c] rounded-[1px]" />
            ))}
          </div>
        </div>
      )}

      {frameType === "torn-paper" && (
        <div
          className="relative bg-[#fdfaf4] p-3 shadow-[0_8px_18px_rgba(43,38,32,0.16)]"
          style={{
            clipPath:
              "polygon(2% 4%, 22% 0%, 45% 3%, 68% 0%, 90% 3%, 100% 8%, 98% 96%, 76% 100%, 52% 97%, 28% 100%, 6% 97%, 0 92%)",
          }}
        >
          <div className="relative w-full aspect-[4/5] overflow-hidden">
            <Image
              src={src}
              alt={alt}
              fill
              sizes={sizes}
              priority={priority}
              onLoad={() => setLoaded(true)}
              className={clsx(
                "object-cover transition-all duration-700",
                loaded ? "blur-0 scale-100" : "blur-md scale-105"
              )}
            />
          </div>
          {caption && (
            <p className="font-hand text-[#4a4238] text-base mt-1.5 truncate">
              {caption}
            </p>
          )}
        </div>
      )}
    </motion.button>
  );
}
