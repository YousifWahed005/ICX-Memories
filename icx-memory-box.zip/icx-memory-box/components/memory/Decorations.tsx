"use client";

import { motion } from "framer-motion";
import clsx from "clsx";

export function TapeStrip({
  className,
  rotate = -4,
}: {
  className?: string;
  rotate?: number;
}) {
  return (
    <motion.span
      aria-hidden
      className={clsx("tape absolute w-20 h-7 rounded-[1px]", className)}
      style={{ rotate }}
      animate={{ rotate: [rotate, rotate + 1.2, rotate] }}
      transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
    />
  );
}

export function PaperNote({
  text,
  className,
  rotate = -3,
}: {
  text: string;
  className?: string;
  rotate?: number;
}) {
  return (
    <motion.div
      aria-hidden
      className={clsx(
        "absolute bg-[#fdfaf4] px-4 py-3 shadow-[0_6px_16px_rgba(43,38,32,0.15)] font-hand text-lg text-[#4a4238] max-w-[180px]",
        className
      )}
      style={{ rotate }}
      initial={{ opacity: 0, y: 10 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      animate={{ y: [0, -4, 0] }}
      transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
    >
      {text}
    </motion.div>
  );
}

export function Sticker({
  emoji,
  className,
}: {
  emoji: string;
  className?: string;
}) {
  return (
    <motion.span
      aria-hidden
      className={clsx("absolute text-3xl md:text-4xl drop-shadow", className)}
      animate={{ rotate: [-8, 8, -8], y: [0, -5, 0] }}
      transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
    >
      {emoji}
    </motion.span>
  );
}
