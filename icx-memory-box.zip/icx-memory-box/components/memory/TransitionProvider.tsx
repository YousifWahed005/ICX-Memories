"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import { useRouter, usePathname } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import Image from "next/image";

interface TransitionCtx {
  openMemory: (href: string, imageSrc: string, accent?: string) => void;
}

const Ctx = createContext<TransitionCtx | null>(null);

export function useMemoryTransition() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useMemoryTransition must be used within provider");
  return ctx;
}

export default function TransitionProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const [state, setState] = useState<{
    active: boolean;
    phase: "in" | "out";
    src: string;
    accent: string;
  }>({ active: false, phase: "in", src: "", accent: "#D97A4E" });
  const pendingHref = useRef<string | null>(null);

  const openMemory = useCallback(
    (href: string, imageSrc: string, accent = "#D97A4E") => {
      pendingHref.current = href;
      setState({ active: true, phase: "in", src: imageSrc, accent });
      window.setTimeout(() => {
        if (pendingHref.current) {
          router.push(pendingHref.current);
        }
      }, 650);
    },
    [router]
  );

  useEffect(() => {
    if (state.active && state.phase === "in") {
      // once the route changes, start the "out" (reveal) phase
      const t = setTimeout(() => {
        setState((s) => ({ ...s, phase: "out" }));
      }, 700);
      return () => clearTimeout(t);
    }
  }, [pathname]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (state.phase === "out") {
      const t = setTimeout(() => {
        setState((s) => ({ ...s, active: false }));
        pendingHref.current = null;
      }, 550);
      return () => clearTimeout(t);
    }
  }, [state.phase]);

  return (
    <Ctx.Provider value={{ openMemory }}>
      {children}
      <AnimatePresence>
        {state.active && (
          <motion.div
            className="fixed inset-0 z-[999] flex items-center justify-center pointer-events-none"
            style={{ background: state.accent }}
            initial={{ opacity: 0 }}
            animate={{
              opacity: state.phase === "in" ? 1 : 0,
            }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.55, ease: [0.65, 0, 0.35, 1] }}
          >
            <motion.div
              className="relative w-[62vmin] h-[78vmin] rounded-sm overflow-hidden shadow-2xl"
              initial={{ scale: 0.55, opacity: 0.4 }}
              animate={{
                scale: state.phase === "in" ? 1.15 : 1.4,
                opacity: state.phase === "in" ? 1 : 0,
              }}
              transition={{ duration: 0.65, ease: [0.65, 0, 0.35, 1] }}
            >
              {state.src && (
                <Image
                  src={state.src}
                  alt=""
                  fill
                  className="object-cover"
                  sizes="70vmin"
                />
              )}
              <div className="absolute inset-0 bg-black/10" />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </Ctx.Provider>
  );
}
