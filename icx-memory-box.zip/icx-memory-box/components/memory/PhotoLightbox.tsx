"use client";

import { useCallback, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import Image from "next/image";
import type { GalleryItem } from "./MemoryGallery";

export default function PhotoLightbox({
  items,
  index,
  onClose,
  onNavigate,
}: {
  items: GalleryItem[];
  index: number;
  onClose: () => void;
  onNavigate: (i: number) => void;
}) {
  const item = items[index];

  const goNext = useCallback(
    () => onNavigate((index + 1) % items.length),
    [index, items.length, onNavigate]
  );
  const goPrev = useCallback(
    () => onNavigate((index - 1 + items.length) % items.length),
    [index, items.length, onNavigate]
  );

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") goNext();
      if (e.key === "ArrowLeft") goPrev();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose, goNext, goPrev]);

  let touchStartX = 0;
  function onTouchStart(e: React.TouchEvent) {
    touchStartX = e.touches[0].clientX;
  }
  function onTouchEnd(e: React.TouchEvent) {
    const dx = e.changedTouches[0].clientX - touchStartX;
    if (dx > 60) goPrev();
    if (dx < -60) goNext();
  }

  return (
    <AnimatePresence>
      <motion.div
        role="dialog"
        aria-modal="true"
        aria-label="Photo viewer"
        className="fixed inset-0 z-[500] bg-[#1b1712]/95 flex items-center justify-center px-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
        onClick={onClose}
        onTouchStart={onTouchStart}
        onTouchEnd={onTouchEnd}
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="Close photo viewer"
          className="absolute top-5 right-5 md:top-8 md:right-8 text-[#F7F1E8] text-3xl leading-none w-10 h-10 flex items-center justify-center hover:opacity-70 focus-visible:outline-2 focus-visible:outline-[#F7F1E8]"
        >
          ×
        </button>

        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            goPrev();
          }}
          aria-label="Previous photo"
          className="hidden md:flex absolute left-4 md:left-8 top-1/2 -translate-y-1/2 text-[#F7F1E8] text-4xl w-12 h-12 items-center justify-center hover:opacity-70"
        >
          ‹
        </button>
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            goNext();
          }}
          aria-label="Next photo"
          className="hidden md:flex absolute right-4 md:right-8 top-1/2 -translate-y-1/2 text-[#F7F1E8] text-4xl w-12 h-12 items-center justify-center hover:opacity-70"
        >
          ›
        </button>

        <motion.div
          key={item.id}
          initial={{ opacity: 0, scale: 0.92, rotate: -1 }}
          animate={{ opacity: 1, scale: 1, rotate: 0 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.35, ease: [0.65, 0, 0.35, 1] }}
          className="relative max-w-3xl w-full max-h-[80vh] flex flex-col items-center"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="relative w-full h-[65vh] bg-[#0f0d0a]">
            <Image
              src={item.image_url}
              alt={item.caption || "memory photo"}
              fill
              sizes="90vw"
              className="object-contain"
              priority
            />
          </div>
          {(item.caption || item.photo_date) && (
            <p className="font-hand text-xl text-[#F7F1E8] mt-4 text-center">
              {item.caption}
              {item.caption && item.photo_date ? " — " : ""}
              {item.photo_date &&
                new Date(item.photo_date).toLocaleDateString("en-US", {
                  month: "short",
                  day: "numeric",
                  year: "numeric",
                })}
            </p>
          )}
          <p className="text-[#F7F1E8]/40 text-sm mt-2">
            {index + 1} / {items.length}
          </p>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
