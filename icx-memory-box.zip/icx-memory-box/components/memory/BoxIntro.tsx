"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

export default function BoxIntro({ onDone }: { onDone: () => void }) {
  const [closing, setClosing] = useState(false);

  const handleOpen = () => {
    setClosing(true);
    setTimeout(onDone, 900);
  };

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-[900] flex items-center justify-center bg-[#2B2620] overflow-hidden"
        initial={{ opacity: 1 }}
        animate={closing ? { opacity: 0 } : { opacity: 1 }}
        transition={{ duration: 0.9, ease: [0.65, 0, 0.35, 1] }}
        style={{ pointerEvents: closing ? "none" : "auto" }}
      >
          {/* faint corner light */}
          <div
            className="absolute inset-0 opacity-40"
            style={{
              background:
                "radial-gradient(circle at 50% 40%, rgba(217,122,78,0.25), transparent 60%)",
            }}
          />

          <div className="relative flex flex-col items-center px-6 text-center">
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: closing ? 0 : 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.8 }}
              className="font-hand text-2xl md:text-3xl text-[#F7F1E8]/80 mb-2"
            >
              Some memories deserve more than a camera roll.
            </motion.p>
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: closing ? 0 : 1, y: 0 }}
              transition={{ delay: 0.55, duration: 0.8 }}
              className="font-hand text-2xl md:text-3xl text-[#F7F1E8]/80 mb-8"
            >
              So we put them in a box.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, scale: 0.85, rotate: -3 }}
              animate={{
                opacity: closing ? 0 : 1,
                scale: closing ? 2.4 : 1,
                rotate: 0,
              }}
              transition={{
                opacity: { delay: 0.9, duration: 0.6 },
                scale: closing
                  ? { duration: 0.9, ease: [0.76, 0, 0.24, 1] }
                  : { delay: 0.9, duration: 0.7, ease: "easeOut" },
              }}
              className="relative"
            >
              <div className="relative w-[220px] h-[160px] md:w-[280px] md:h-[200px]">
                {/* box lid */}
                <motion.div
                  className="absolute inset-0 rounded-sm shadow-2xl"
                  style={
                    {
                      background:
                        "linear-gradient(155deg, #C99A6E 0%, #B5824F 55%, #8f6339 100%)",
                      border: "1px solid rgba(0,0,0,0.2)",
                      transformOrigin: "top center",
                      transformStyle: "preserve-3d",
                    } as React.CSSProperties
                  }
                  animate={
                    closing
                      ? { rotateX: -110, y: -40, opacity: 0.4 }
                      : { rotateX: 0, y: 0 }
                  }
                  transition={{ duration: 0.8, ease: "easeInOut" }}
                />
                <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-[85%] h-2 bg-black/25 blur-md rounded-full" />
              </div>

              <h1 className="font-display italic text-3xl md:text-4xl text-[#F7F1E8] mt-6 tracking-tight">
                AIESEC in Suez — ICX 2026
              </h1>
            </motion.div>

            <motion.button
              type="button"
              onClick={handleOpen}
              initial={{ opacity: 0 }}
              animate={{ opacity: closing ? 0 : 1 }}
              transition={{ delay: 1.5, duration: 0.6 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.96 }}
              className="mt-10 px-8 py-3 rounded-full border border-[#F7F1E8]/40 text-[#F7F1E8] font-body text-sm tracking-[0.2em] uppercase hover:bg-[#F7F1E8]/10 transition-colors"
            >
              Open the box
            </motion.button>
          </div>
      </motion.div>
    </AnimatePresence>
  );
}
