"use client";

import { useState } from "react";
import PhotoFrame from "./PhotoFrame";
import PhotoLightbox from "./PhotoLightbox";
import type { FrameType } from "@/lib/types";

export interface GalleryItem {
  id: string;
  image_url: string;
  caption?: string | null;
  photo_date?: string | null;
  frame_type?: FrameType;
  rotation?: number;
}

export default function MemoryGallery({
  items,
  accent = "var(--color-accent-warm)",
  emptyLabel,
}: {
  items: GalleryItem[];
  accent?: string;
  emptyLabel?: string;
}) {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  if (!items.length) {
    return (
      <p className="font-hand text-xl text-center text-[color:var(--color-ink)]/50 py-16">
        {emptyLabel || "Nothing here yet."}
      </p>
    );
  }

  return (
    <>
      <div className="columns-2 sm:columns-3 lg:columns-4 gap-x-6 [&>*]:mb-10">
        {items.map((item, i) => (
          <div key={item.id} className="break-inside-avoid">
            <PhotoFrame
              src={item.image_url}
              alt={item.caption || "memory"}
              caption={item.caption}
              date={item.photo_date}
              frameType={item.frame_type || "polaroid"}
              rotation={item.rotation ?? 0}
              accent={accent}
              onClick={() => setActiveIndex(i)}
              className="w-full"
            />
          </div>
        ))}
      </div>

      {activeIndex !== null && (
        <PhotoLightbox
          items={items}
          index={activeIndex}
          onClose={() => setActiveIndex(null)}
          onNavigate={setActiveIndex}
        />
      )}
    </>
  );
}
