"use client";

import { motion } from "framer-motion";
import EPCard from "./EPCard";
import type { EPProfile } from "@/lib/types";

export default function EPDiscovery({ eps }: { eps: EPProfile[] }) {
  return (
    <section className="relative z-10 max-w-6xl mx-auto px-6 md:px-10 py-20 md:py-28">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.7 }}
        className="text-center mb-14"
      >
        <p className="font-hand text-2xl text-[color:var(--color-accent-blue)] mb-1">
          dig a little deeper
        </p>
        <h2 className="font-display italic text-3xl md:text-5xl text-[color:var(--color-ink)]">
          Everyone we shared this chapter with
        </h2>
        <p className="mt-3 text-[color:var(--color-ink)]/55 max-w-lg mx-auto">
          {eps.length} exchange participants, one Suez family. Tap anyone to
          open their own memory box.
        </p>
      </motion.div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-x-6 gap-y-14 place-items-center">
        {eps.map((ep, i) => (
          <EPCard key={ep.id} ep={ep} index={i} />
        ))}
      </div>
    </section>
  );
}
