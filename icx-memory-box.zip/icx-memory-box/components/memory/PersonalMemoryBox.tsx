"use client";

import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import type { EPProfile } from "@/lib/types";

function formatDate(d: string) {
  return new Date(d).toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  });
}

export default function PersonalMemoryBox({ ep }: { ep: EPProfile }) {
  return (
    <header
      className="relative pt-10 pb-16 md:pt-16 md:pb-24 px-6 overflow-hidden"
      style={{
        background: `radial-gradient(ellipse at 50% 0%, color-mix(in srgb, ${ep.theme_color} 16%, transparent), transparent 60%), var(--color-paper)`,
      }}
    >
      <div className="max-w-3xl mx-auto">
        <Link
          href="/"
          className="inline-flex items-center gap-1.5 text-sm text-[color:var(--color-ink)]/50 hover:text-[color:var(--color-ink)] transition-colors mb-10"
        >
          ← back to the box
        </Link>

        <div className="flex flex-col items-center text-center">
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.7 }}
            className="font-hand text-2xl mb-4"
            style={{ color: ep.theme_color }}
          >
            this is everything we kept from your chapter with us
          </motion.p>

          <motion.div
            initial={{ opacity: 0, scale: 0.9, rotate: -3 }}
            animate={{ opacity: 1, scale: 1, rotate: -3 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="relative bg-[#fdfaf4] p-3 pb-8 shadow-[0_14px_30px_rgba(43,38,32,0.22)] mb-6"
          >
            <div className="relative w-40 h-48 md:w-48 md:h-56 overflow-hidden">
              <Image
                src={ep.profile_image}
                alt={ep.name}
                fill
                sizes="200px"
                className="object-cover"
                priority
              />
            </div>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.25 }}
            className="font-display italic text-4xl md:text-6xl text-[color:var(--color-ink)]"
          >
            {ep.name}
          </motion.h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.35 }}
            className="mt-2 text-lg text-[color:var(--color-ink)]/60"
          >
            {ep.country}
          </motion.p>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.45 }}
            className="mt-5 inline-flex items-center gap-3 px-4 py-2 rounded-full text-sm"
            style={{
              background: `color-mix(in srgb, ${ep.theme_color} 12%, transparent)`,
              color: ep.theme_color,
            }}
          >
            <span>{formatDate(ep.joined_date)}</span>
            <span>—</span>
            <span>{formatDate(ep.left_date)}</span>
          </motion.div>
        </div>
      </div>
    </header>
  );
}
