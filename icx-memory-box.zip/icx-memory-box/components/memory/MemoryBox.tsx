"use client";

import { useRef } from "react";
import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import PhotoFrame from "./PhotoFrame";
import { TapeStrip, PaperNote, Sticker } from "./Decorations";
import type { GeneralMemory } from "@/lib/types";

function ParallaxLayer({
  depth,
  mx,
  my,
  children,
  className,
}: {
  depth: number;
  mx: ReturnType<typeof useMotionValue<number>>;
  my: ReturnType<typeof useMotionValue<number>>;
  children: React.ReactNode;
  className?: string;
}) {
  const x = useTransform(mx, (v) => v * depth);
  const y = useTransform(my, (v) => v * depth);
  return (
    <motion.div style={{ x, y }} className={className}>
      {children}
    </motion.div>
  );
}

export default function MemoryBox({
  memories,
  onSelect,
}: {
  memories: GeneralMemory[];
  onSelect: (m: GeneralMemory) => void;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const rawX = useMotionValue(0);
  const rawY = useMotionValue(0);
  const mx = useSpring(rawX, { stiffness: 60, damping: 20 });
  const my = useSpring(rawY, { stiffness: 60, damping: 20 });

  function handleMouseMove(e: React.MouseEvent<HTMLDivElement>) {
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;
    const relX = (e.clientX - rect.left) / rect.width - 0.5;
    const relY = (e.clientY - rect.top) / rect.height - 0.5;
    rawX.set(relX * 30);
    rawY.set(relY * 30);
  }

  const featured = memories.filter((m) => m.featured).slice(0, 8);
  const rest = memories.filter((m) => !m.featured);
  const display = featured.length ? featured : memories.slice(0, 8);

  return (
    <div
      ref={containerRef}
      onMouseMove={handleMouseMove}
      className="relative w-full min-h-[100svh] paper-texture overflow-hidden"
      style={{
        background:
          "radial-gradient(ellipse at 30% 20%, rgba(217,122,78,0.08), transparent 55%), radial-gradient(ellipse at 80% 70%, rgba(44,110,158,0.07), transparent 50%), var(--color-paper)",
      }}
    >
      {/* header */}
      <div className="relative z-20 pt-16 md:pt-20 text-center px-6">
        <motion.p
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="font-hand text-2xl text-[color:var(--color-accent-warm)] mb-2"
        >
          AIESEC in Suez, ICX 2026
        </motion.p>
        <motion.h1
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.1 }}
          className="font-display italic text-4xl md:text-6xl text-[color:var(--color-ink)] tracking-tight"
        >
          The Memory Box
        </motion.h1>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.9, delay: 0.3 }}
          className="mt-3 text-[color:var(--color-ink)]/60 font-body max-w-md mx-auto"
        >
          Everything we kept from a chapter we shared. Move your mouse around
          — then start digging.
        </motion.p>
      </div>

      {/* scattered decorations */}
      <ParallaxLayer depth={-0.6} mx={mx} my={my} className="absolute top-[18%] left-[6%] hidden md:block">
        <Sticker emoji="📌" />
      </ParallaxLayer>
      <ParallaxLayer depth={0.8} mx={mx} my={my} className="absolute top-[12%] right-[10%] hidden md:block">
        <PaperNote text="never forget this trip" rotate={4} />
      </ParallaxLayer>
      <ParallaxLayer depth={-0.4} mx={mx} my={my} className="absolute bottom-[8%] left-[10%] hidden md:block">
        <Sticker emoji="🧡" />
      </ParallaxLayer>
      <ParallaxLayer depth={0.5} mx={mx} my={my} className="absolute bottom-[20%] right-[6%] hidden md:block">
        <TapeStrip rotate={12} className="w-24 h-8" />
      </ParallaxLayer>

      {/* main collage */}
      <div className="relative z-10 max-w-6xl mx-auto px-6 md:px-10 pt-16 pb-24">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-x-6 gap-y-14 md:gap-y-20 place-items-center">
          {display.map((m, i) => {
            const depth = ((i % 3) - 1) * 0.5;
            const bigger = i === 0 || i === 3;
            return (
              <ParallaxLayer
                key={m.id}
                depth={depth}
                mx={mx}
                my={my}
                className={bigger ? "col-span-2 w-full max-w-[420px]" : "w-full max-w-[240px]"}
              >
                <PhotoFrame
                  src={m.image_url}
                  alt={m.caption || "AIESEC Suez memory"}
                  caption={m.caption}
                  date={m.photo_date}
                  frameType={m.frame_type}
                  rotation={m.rotation}
                  onClick={() => onSelect(m)}
                  priority={i < 2}
                />
              </ParallaxLayer>
            );
          })}
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1, y: [0, 8, 0] }}
        transition={{ opacity: { delay: 1 }, y: { duration: 2, repeat: Infinity } }}
        className="relative z-10 flex flex-col items-center pb-10 text-[color:var(--color-ink)]/50"
      >
        <span className="font-hand text-lg mb-1">keep scrolling, there&apos;s more</span>
        <span className="text-xl">↓</span>
      </motion.div>
    </div>
  );
}
