"use client";

import { useState } from "react";
import BoxIntro from "./BoxIntro";
import MemoryBox from "./MemoryBox";
import EPDiscovery from "./EPDiscovery";
import MemoryGallery from "./MemoryGallery";
import PhotoLightbox from "./PhotoLightbox";
import Footer from "./Footer";
import { motion } from "framer-motion";
import type { EPProfile, GeneralMemory } from "@/lib/types";

export default function HomeClient({
  eps,
  memories,
}: {
  eps: EPProfile[];
  memories: GeneralMemory[];
}) {
  const [introDone, setIntroDone] = useState(false);
  const [heroLightbox, setHeroLightbox] = useState<GeneralMemory | null>(null);

  const featuredIds = new Set(
    memories.filter((m) => m.featured).slice(0, 8).map((m) => m.id)
  );
  const remaining = memories.filter((m) => !featuredIds.has(m.id));

  return (
    <main className="relative">
      {!introDone && <BoxIntro onDone={() => setIntroDone(true)} />}

      <MemoryBox memories={memories} onSelect={setHeroLightbox} />

      <EPDiscovery eps={eps} />

      {remaining.length > 0 && (
        <section className="relative z-10 max-w-6xl mx-auto px-6 md:px-10 pb-20">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="text-center mb-12"
          >
            <p className="font-hand text-2xl text-[color:var(--color-accent-warm)] mb-1">
              still more at the bottom of the box
            </p>
            <h2 className="font-display italic text-3xl md:text-4xl text-[color:var(--color-ink)]">
              Every other moment we saved
            </h2>
          </motion.div>
          <MemoryGallery items={remaining} />
        </section>
      )}

      <Footer />

      {heroLightbox && (
        <PhotoLightbox
          items={memories}
          index={memories.findIndex((m) => m.id === heroLightbox.id)}
          onClose={() => setHeroLightbox(null)}
          onNavigate={(i) => setHeroLightbox(memories[i])}
        />
      )}
    </main>
  );
}
