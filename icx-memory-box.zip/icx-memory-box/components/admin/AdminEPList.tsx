"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { createClient } from "@/lib/supabase/client";
import type { EPProfile } from "@/lib/types";

export default function AdminEPList({ initialEPs }: { initialEPs: EPProfile[] }) {
  const [eps, setEps] = useState(initialEPs);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  async function handleDelete(id: string, name: string) {
    if (!confirm(`Delete ${name} and all their photos? This can't be undone.`))
      return;
    setDeletingId(id);
    const supabase = createClient();
    const { error } = await supabase.from("ep_profiles").delete().eq("id", id);
    setDeletingId(null);
    if (error) {
      alert(error.message);
      return;
    }
    setEps((prev) => prev.filter((ep) => ep.id !== id));
  }

  return (
    <div>
      <Link
        href="/admin/ep/new"
        className="inline-flex items-center gap-2 mb-6 px-4 py-2.5 rounded-full bg-[color:var(--color-accent-warm)] text-white text-sm font-medium hover:opacity-90 transition-opacity"
      >
        + Add EP
      </Link>

      {eps.length === 0 ? (
        <p className="text-[color:var(--color-ink)]/50 py-10 text-center">
          No EPs yet. Add your first one.
        </p>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {eps.map((ep) => (
            <div
              key={ep.id}
              className="bg-white rounded-lg shadow-sm border border-[color:var(--color-ink)]/10 p-4 flex gap-4"
            >
              <div className="relative w-16 h-16 rounded overflow-hidden shrink-0 bg-[color:var(--color-surface)]">
                {ep.profile_image && (
                  <Image
                    src={ep.profile_image}
                    alt={ep.name}
                    fill
                    sizes="64px"
                    className="object-cover"
                  />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span
                    className="w-2.5 h-2.5 rounded-full shrink-0"
                    style={{ background: ep.theme_color }}
                  />
                  <p className="font-medium truncate">{ep.name}</p>
                </div>
                <p className="text-sm text-[color:var(--color-ink)]/50">
                  {ep.country}
                </p>
                <div className="flex gap-3 mt-2">
                  <Link
                    href={`/admin/ep/${ep.id}`}
                    className="text-sm text-[color:var(--color-accent-blue)] hover:underline"
                  >
                    Manage
                  </Link>
                  <button
                    type="button"
                    onClick={() => handleDelete(ep.id, ep.name)}
                    disabled={deletingId === ep.id}
                    className="text-sm text-red-600 hover:underline disabled:opacity-50"
                  >
                    {deletingId === ep.id ? "Deleting…" : "Delete"}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
