"use client";

import { useState } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import ImageUploader from "./ImageUploader";
import type { EPProfile } from "@/lib/types";

const THEME_PRESETS = [
  "#D97A4E",
  "#2C6E9E",
  "#7A9E5E",
  "#B5546E",
  "#C99A2E",
  "#8E6FB0",
];

export default function AdminEPForm({ ep }: { ep?: EPProfile }) {
  const router = useRouter();
  const isEdit = Boolean(ep);

  const [name, setName] = useState(ep?.name || "");
  const [country, setCountry] = useState(ep?.country || "");
  const [profileImage, setProfileImage] = useState(ep?.profile_image || "");
  const [joinedDate, setJoinedDate] = useState(ep?.joined_date || "");
  const [leftDate, setLeftDate] = useState(ep?.left_date || "");
  const [themeColor, setThemeColor] = useState(ep?.theme_color || THEME_PRESETS[0]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!profileImage) {
      setError("Please upload a profile photo.");
      return;
    }
    setSaving(true);
    setError(null);
    const supabase = createClient();

    const payload = {
      name,
      country,
      profile_image: profileImage,
      joined_date: joinedDate,
      left_date: leftDate,
      theme_color: themeColor,
    };

    if (isEdit && ep) {
      const { error } = await supabase
        .from("ep_profiles")
        .update(payload)
        .eq("id", ep.id);
      setSaving(false);
      if (error) return setError(error.message);
      router.refresh();
    } else {
      const { data, error } = await supabase
        .from("ep_profiles")
        .insert(payload)
        .select()
        .single();
      setSaving(false);
      if (error) return setError(error.message);
      router.push(`/admin/ep/${data.id}`);
      router.refresh();
    }
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-white rounded-lg border border-[color:var(--color-ink)]/10 p-6 space-y-5 max-w-xl"
    >
      <div>
        <label className="block text-sm font-medium mb-1.5">Full name</label>
        <input
          required
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="w-full px-3 py-2 rounded border border-[color:var(--color-ink)]/15 focus-visible:outline-2 focus-visible:outline-[color:var(--color-accent-blue)]"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1.5">Country</label>
        <input
          required
          value={country}
          onChange={(e) => setCountry(e.target.value)}
          className="w-full px-3 py-2 rounded border border-[color:var(--color-ink)]/15 focus-visible:outline-2 focus-visible:outline-[color:var(--color-accent-blue)]"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1.5">Profile photo</label>
        {profileImage && (
          <div className="relative w-24 h-24 rounded overflow-hidden mb-2">
            <Image src={profileImage} alt="Profile preview" fill sizes="96px" className="object-cover" />
          </div>
        )}
        <ImageUploader
          folder="profiles"
          onUploaded={(urls) => setProfileImage(urls[0])}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1.5">Joined date</label>
          <input
            type="date"
            required
            value={joinedDate}
            onChange={(e) => setJoinedDate(e.target.value)}
            className="w-full px-3 py-2 rounded border border-[color:var(--color-ink)]/15 focus-visible:outline-2 focus-visible:outline-[color:var(--color-accent-blue)]"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1.5">Left date</label>
          <input
            type="date"
            required
            value={leftDate}
            onChange={(e) => setLeftDate(e.target.value)}
            className="w-full px-3 py-2 rounded border border-[color:var(--color-ink)]/15 focus-visible:outline-2 focus-visible:outline-[color:var(--color-accent-blue)]"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1.5">Theme color</label>
        <div className="flex items-center gap-2 flex-wrap">
          {THEME_PRESETS.map((c) => (
            <button
              type="button"
              key={c}
              onClick={() => setThemeColor(c)}
              className="w-8 h-8 rounded-full border-2"
              style={{
                background: c,
                borderColor: themeColor === c ? "#2B2620" : "transparent",
              }}
              aria-label={`Use color ${c}`}
            />
          ))}
          <input
            type="color"
            value={themeColor}
            onChange={(e) => setThemeColor(e.target.value)}
            className="w-8 h-8 rounded cursor-pointer border border-[color:var(--color-ink)]/15"
            aria-label="Custom theme color"
          />
        </div>
      </div>

      {error && <p className="text-red-600 text-sm">{error}</p>}

      <button
        type="submit"
        disabled={saving}
        className="px-6 py-2.5 rounded-full bg-[color:var(--color-ink)] text-[color:var(--color-paper)] text-sm font-medium hover:opacity-90 transition-opacity disabled:opacity-50"
      >
        {saving ? "Saving…" : isEdit ? "Save changes" : "Create EP"}
      </button>
    </form>
  );
}
