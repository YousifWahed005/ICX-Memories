"use client";

import { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import { uploadImage } from "@/lib/storage";
import clsx from "clsx";

export default function ImageUploader({
  folder,
  multiple = false,
  onUploaded,
  label,
}: {
  folder: string;
  multiple?: boolean;
  onUploaded: (urls: string[]) => void;
  label?: string;
}) {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState<{ done: number; total: number } | null>(
    null
  );
  const [error, setError] = useState<string | null>(null);

  const onDrop = useCallback(
    async (accepted: File[]) => {
      if (!accepted.length) return;
      setError(null);
      setUploading(true);
      setProgress({ done: 0, total: accepted.length });
      const urls: string[] = [];
      try {
        for (const file of accepted) {
          const url = await uploadImage(file, folder);
          urls.push(url);
          setProgress((p) => (p ? { ...p, done: p.done + 1 } : p));
        }
        onUploaded(urls);
      } catch (e) {
        setError(e instanceof Error ? e.message : "Upload failed");
      } finally {
        setUploading(false);
        setProgress(null);
      }
    },
    [folder, onUploaded]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    multiple,
    accept: { "image/*": [] },
  });

  return (
    <div>
      <div
        {...getRootProps()}
        className={clsx(
          "border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors",
          isDragActive
            ? "border-[color:var(--color-accent-blue)] bg-[color:var(--color-accent-blue)]/5"
            : "border-[color:var(--color-ink)]/20 hover:border-[color:var(--color-ink)]/40"
        )}
      >
        <input {...getInputProps()} />
        {uploading ? (
          <p className="text-sm text-[color:var(--color-ink)]/60">
            Uploading {progress ? `${progress.done}/${progress.total}` : "…"}
          </p>
        ) : (
          <p className="text-sm text-[color:var(--color-ink)]/60">
            {label ||
              (multiple
                ? "Drag & drop photos here, or click to browse"
                : "Drag & drop a photo here, or click to browse")}
          </p>
        )}
      </div>
      {error && <p className="text-red-600 text-sm mt-2">{error}</p>}
    </div>
  );
}
