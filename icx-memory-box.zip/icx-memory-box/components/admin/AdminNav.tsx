"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import clsx from "clsx";

const links = [
  { href: "/admin", label: "EPs" },
  { href: "/admin/memories", label: "General Memories" },
];

export default function AdminNav() {
  const pathname = usePathname();
  const router = useRouter();

  async function handleSignOut() {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push("/admin/login");
    router.refresh();
  }

  return (
    <nav className="bg-[#2B2620] text-[#F7F1E8]">
      <div className="max-w-5xl mx-auto px-6 h-16 flex items-center justify-between">
        <div className="flex items-center gap-8">
          <span className="font-display italic text-lg">
            ICX Memory Box — Admin
          </span>
          <div className="hidden sm:flex gap-1">
            {links.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className={clsx(
                  "px-3 py-1.5 rounded-full text-sm transition-colors",
                  pathname === l.href
                    ? "bg-[#F7F1E8] text-[#2B2620]"
                    : "hover:bg-white/10"
                )}
              >
                {l.label}
              </Link>
            ))}
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Link
            href="/"
            target="_blank"
            className="text-sm text-[#F7F1E8]/60 hover:text-[#F7F1E8]"
          >
            View site ↗
          </Link>
          <button
            type="button"
            onClick={handleSignOut}
            className="text-sm px-3 py-1.5 rounded-full border border-white/20 hover:bg-white/10"
          >
            Sign out
          </button>
        </div>
      </div>
      <div className="sm:hidden flex gap-1 px-6 pb-3">
        {links.map((l) => (
          <Link
            key={l.href}
            href={l.href}
            className={clsx(
              "px-3 py-1.5 rounded-full text-sm",
              pathname === l.href ? "bg-[#F7F1E8] text-[#2B2620]" : "bg-white/10"
            )}
          >
            {l.label}
          </Link>
        ))}
      </div>
    </nav>
  );
}
