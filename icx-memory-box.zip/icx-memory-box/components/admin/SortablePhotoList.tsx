"use client";

import { useState } from "react";
import Image from "next/image";
import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext,
  arrayMove,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { createClient } from "@/lib/supabase/client";
import { deleteImageByUrl } from "@/lib/storage";
import ImageUploader from "./ImageUploader";
import { nextAutoLayout } from "@/lib/layout";
import type { EPPhoto, GeneralMemory } from "@/lib/types";

type Photo = EPPhoto | GeneralMemory;

function isGeneral(p: Photo): p is GeneralMemory {
  return (p as GeneralMemory).featured !== undefined;
}

function SortableRow({
  photo,
  showFeatured,
  onUpdate,
  onDelete,
}: {
  photo: Photo;
  showFeatured: boolean;
  onUpdate: (id: string, patch: Partial<Photo>) => void;
  onDelete: (photo: Photo) => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } =
    useSortable({ id: photo.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="flex items-center gap-3 bg-white rounded-lg border border-[color:var(--color-ink)]/10 p-3"
    >
      <button
        type="button"
        {...attributes}
        {...listeners}
        className="cursor-grab active:cursor-grabbing text-[color:var(--color-ink)]/30 hover:text-[color:var(--color-ink)]/60 px-1"
        aria-label="Drag to reorder"
      >
        ⠿
      </button>
      <div className="relative w-16 h-16 rounded overflow-hidden shrink-0 bg-[color:var(--color-surface)]">
        <Image src={photo.image_url} alt="" fill sizes="64px" className="object-cover" />
      </div>
      <div className="flex-1 grid sm:grid-cols-2 gap-2">
        <input
          placeholder="Caption (optional)"
          defaultValue={photo.caption || ""}
          onBlur={(e) => onUpdate(photo.id, { caption: e.target.value } as Partial<Photo>)}
          className="px-2 py-1.5 text-sm rounded border border-[color:var(--color-ink)]/15"
        />
        <input
          type="date"
          defaultValue={photo.photo_date || ""}
          onBlur={(e) => onUpdate(photo.id, { photo_date: e.target.value } as Partial<Photo>)}
          className="px-2 py-1.5 text-sm rounded border border-[color:var(--color-ink)]/15"
        />
      </div>
      {showFeatured && isGeneral(photo) && (
        <label className="flex items-center gap-1.5 text-xs text-[color:var(--color-ink)]/60 shrink-0">
          <input
            type="checkbox"
            checked={photo.featured}
            onChange={(e) =>
              onUpdate(photo.id, { featured: e.target.checked } as Partial<Photo>)
            }
          />
          Featured
        </label>
      )}
      <button
        type="button"
        onClick={() => onDelete(photo)}
        className="text-sm text-red-600 hover:underline shrink-0"
      >
        Delete
      </button>
    </div>
  );
}

export default function SortablePhotoList({
  table,
  epId,
  initialPhotos,
}: {
  table: "ep_photos" | "general_memories";
  epId?: string;
  initialPhotos: Photo[];
}) {
  const [photos, setPhotos] = useState<Photo[]>(initialPhotos);
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 6 } }));
  const showFeatured = table === "general_memories";

  async function handleUploaded(urls: string[]) {
    const supabase = createClient();
    const startCount = photos.length;
    const rows = urls.map((url, i) => {
      const { frame_type, rotation } = nextAutoLayout(startCount + i);
      return {
        image_url: url,
        sort_order: startCount + i,
        frame_type,
        rotation,
        ...(table === "ep_photos" ? { ep_id: epId } : { featured: false }),
      };
    });
    const { data, error } = await supabase.from(table).insert(rows).select();
    if (error) {
      alert(error.message);
      return;
    }
    setPhotos((prev) => [...prev, ...(data as Photo[])]);
  }

  async function handleUpdate(id: string, patch: Partial<Photo>) {
    setPhotos((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...patch } : p))
    );
    const supabase = createClient();
    await supabase.from(table).update(patch).eq("id", id);
  }

  async function handleDelete(photo: Photo) {
    if (!confirm("Delete this photo?")) return;
    setPhotos((prev) => prev.filter((p) => p.id !== photo.id));
    const supabase = createClient();
    await supabase.from(table).delete().eq("id", photo.id);
    await deleteImageByUrl(photo.image_url);
  }

  async function handleDragEnd(event: DragEndEvent) {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    setPhotos((prev) => {
      const oldIndex = prev.findIndex((p) => p.id === active.id);
      const newIndex = prev.findIndex((p) => p.id === over.id);
      const reordered = arrayMove(prev, oldIndex, newIndex);
      const supabase = createClient();
      reordered.forEach((p, i) => {
        if (p.sort_order !== i) {
          supabase.from(table).update({ sort_order: i }).eq("id", p.id);
        }
      });
      return reordered.map((p, i) => ({ ...p, sort_order: i }));
    });
  }

  return (
    <div className="space-y-4">
      <ImageUploader
        folder={table === "ep_photos" ? `ep-photos/${epId}` : "general-memories"}
        multiple
        onUploaded={handleUploaded}
        label="Drag & drop photos here — they'll auto-layout into the memory box"
      />

      {photos.length === 0 ? (
        <p className="text-[color:var(--color-ink)]/50 text-sm py-6 text-center">
          No photos yet.
        </p>
      ) : (
        <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
          <SortableContext items={photos.map((p) => p.id)} strategy={verticalListSortingStrategy}>
            <div className="space-y-2">
              {photos.map((photo) => (
                <SortableRow
                  key={photo.id}
                  photo={photo}
                  showFeatured={showFeatured}
                  onUpdate={handleUpdate}
                  onDelete={handleDelete}
                />
              ))}
            </div>
          </SortableContext>
        </DndContext>
      )}
    </div>
  );
}
