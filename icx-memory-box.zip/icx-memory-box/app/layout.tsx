import type { Metadata } from "next";
import { Fraunces, Inter, Caveat } from "next/font/google";
import TransitionProvider from "@/components/memory/TransitionProvider";
import "./globals.css";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-display",
  weight: ["400", "500", "600", "700", "900"],
  style: ["normal", "italic"],
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-body",
  weight: ["400", "500", "600"],
});

const caveat = Caveat({
  subsets: ["latin"],
  variable: "--font-hand",
  weight: ["500", "600", "700"],
});

export const metadata: Metadata = {
  metadataBase: new URL(
    process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"
  ),
  title: "ICX Testimonials — AIESEC in Suez",
  description:
    "A digital memory box for everyone who was part of AIESEC in Suez, ICX 2026. Open the box.",
  openGraph: {
    title: "ICX Testimonials — AIESEC in Suez",
    description:
      "Some memories deserve more than a camera roll. So we put them in a box.",
    images: ["/og-image.jpg"],
    type: "website",
  },
  icons: { icon: "/favicon.ico" },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body
        className={`${fraunces.variable} ${inter.variable} ${caveat.variable} antialiased`}
      >
        <TransitionProvider>{children}</TransitionProvider>
      </body>
    </html>
  );
}
