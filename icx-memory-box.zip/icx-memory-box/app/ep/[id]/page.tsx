import { notFound } from "next/navigation";
import { getEPWithPhotos } from "@/lib/queries";
import PersonalMemoryBox from "@/components/memory/PersonalMemoryBox";
import MemoryGallery from "@/components/memory/MemoryGallery";
import Footer from "@/components/memory/Footer";
import type { Metadata } from "next";

export const revalidate = 30;

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}): Promise<Metadata> {
  const { id } = await params;
  const ep = await getEPWithPhotos(id);
  if (!ep) return { title: "Not found — ICX Memory Box" };
  return {
    title: `${ep.name}'s Memory Box — ICX Suez 2026`,
    description: `Everything we kept from ${ep.name}'s chapter with AIESEC in Suez.`,
    openGraph: {
      title: `${ep.name}'s Memory Box — ICX Suez 2026`,
      images: [ep.profile_image],
    },
  };
}

export default async function EPPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const ep = await getEPWithPhotos(id);
  if (!ep) notFound();

  return (
    <main className="relative min-h-screen paper-texture">
      <PersonalMemoryBox ep={ep} />
      <section className="max-w-5xl mx-auto px-6 md:px-10 pb-24">
        <MemoryGallery
          items={ep.photos}
          accent={ep.theme_color}
          emptyLabel="Still unpacking this box..."
        />
      </section>
      <Footer />
    </main>
  );
}
