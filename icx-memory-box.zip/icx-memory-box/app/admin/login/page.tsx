"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function AdminLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const supabase = createClient();
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    setLoading(false);
    if (error) {
      setError(error.message);
      return;
    }
    router.push("/admin");
    router.refresh();
  }

  return (
    <main className="min-h-screen flex items-center justify-center bg-[color:var(--color-paper)] px-6">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-sm bg-[#fdfaf4] rounded-lg shadow-[0_12px_30px_rgba(43,38,32,0.15)] p-8"
      >
        <p className="font-hand text-2xl text-[color:var(--color-accent-warm)] mb-1">
          admin only
        </p>
        <h1 className="font-display italic text-2xl text-[color:var(--color-ink)] mb-6">
          Sign in to the box
        </h1>

        <label className="block text-sm text-[color:var(--color-ink)]/70 mb-1">
          Email
        </label>
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full mb-4 px-3 py-2 rounded border border-[color:var(--color-ink)]/15 bg-white focus-visible:outline-2 focus-visible:outline-[color:var(--color-accent-blue)]"
        />

        <label className="block text-sm text-[color:var(--color-ink)]/70 mb-1">
          Password
        </label>
        <input
          type="password"
          required
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full mb-6 px-3 py-2 rounded border border-[color:var(--color-ink)]/15 bg-white focus-visible:outline-2 focus-visible:outline-[color:var(--color-accent-blue)]"
        />

        {error && (
          <p className="text-red-600 text-sm mb-4" role="alert">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full py-2.5 rounded bg-[color:var(--color-ink)] text-[color:var(--color-paper)] font-medium hover:opacity-90 transition-opacity disabled:opacity-50"
        >
          {loading ? "Signing in…" : "Sign in"}
        </button>
      </form>
    </main>
  );
}
