import { createClient } from "@/lib/supabase/server";
import SortablePhotoList from "@/components/admin/SortablePhotoList";
import type { GeneralMemory } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function AdminMemoriesPage() {
  const supabase = await createClient();
  const { data: memories } = await supabase
    .from("general_memories")
    .select("*")
    .order("sort_order", { ascending: true });

  return (
    <div>
      <h1 className="font-display italic text-3xl text-[color:var(--color-ink)] mb-1">
        General Memories
      </h1>
      <p className="text-[color:var(--color-ink)]/50 text-sm mb-8">
        Group photos, events, and trips not tied to a specific EP. Featured
        photos appear front-and-center in the homepage memory box.
      </p>
      <SortablePhotoList
        table="general_memories"
        initialPhotos={(memories as GeneralMemory[]) || []}
      />
    </div>
  );
}
