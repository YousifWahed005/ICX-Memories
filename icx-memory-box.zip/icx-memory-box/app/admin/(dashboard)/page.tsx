import { getAllEPs } from "@/lib/queries";
import AdminEPList from "@/components/admin/AdminEPList";

export const dynamic = "force-dynamic";

export default async function AdminHomePage() {
  const eps = await getAllEPs();
  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display italic text-3xl text-[color:var(--color-ink)]">
            Exchange Participants
          </h1>
          <p className="text-[color:var(--color-ink)]/50 text-sm mt-1">
            {eps.length} EP{eps.length === 1 ? "" : "s"} in the box
          </p>
        </div>
      </div>
      <AdminEPList initialEPs={eps} />
    </div>
  );
}
