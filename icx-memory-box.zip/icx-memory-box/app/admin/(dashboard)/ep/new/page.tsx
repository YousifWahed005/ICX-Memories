import AdminEPForm from "@/components/admin/AdminEPForm";
import Link from "next/link";

export default function NewEPPage() {
  return (
    <div>
      <Link href="/admin" className="text-sm text-[color:var(--color-ink)]/50 hover:underline">
        ← back to EPs
      </Link>
      <h1 className="font-display italic text-3xl text-[color:var(--color-ink)] mt-3 mb-6">
        Add a new EP
      </h1>
      <AdminEPForm />
    </div>
  );
}
