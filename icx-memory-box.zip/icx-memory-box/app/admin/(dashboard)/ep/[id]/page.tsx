import { notFound } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import AdminEPForm from "@/components/admin/AdminEPForm";
import SortablePhotoList from "@/components/admin/SortablePhotoList";
import type { EPProfile, EPPhoto } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function EditEPPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const supabase = await createClient();

  const { data: ep } = await supabase
    .from("ep_profiles")
    .select("*")
    .eq("id", id)
    .single();

  if (!ep) notFound();

  const { data: photos } = await supabase
    .from("ep_photos")
    .select("*")
    .eq("ep_id", id)
    .order("sort_order", { ascending: true });

  return (
    <div>
      <Link href="/admin" className="text-sm text-[color:var(--color-ink)]/50 hover:underline">
        ← back to EPs
      </Link>
      <h1 className="font-display italic text-3xl text-[color:var(--color-ink)] mt-3 mb-8">
        {(ep as EPProfile).name}
      </h1>

      <div className="grid lg:grid-cols-2 gap-10">
        <section>
          <h2 className="text-sm font-semibold uppercase tracking-wide text-[color:var(--color-ink)]/50 mb-3">
            Profile
          </h2>
          <AdminEPForm ep={ep as EPProfile} />
        </section>

        <section>
          <h2 className="text-sm font-semibold uppercase tracking-wide text-[color:var(--color-ink)]/50 mb-3">
            Photos ({photos?.length || 0})
          </h2>
          <SortablePhotoList
            table="ep_photos"
            epId={id}
            initialPhotos={(photos as EPPhoto[]) || []}
          />
        </section>
      </div>
    </div>
  );
}
