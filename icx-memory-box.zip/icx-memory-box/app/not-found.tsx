import Link from "next/link";

export default function NotFound() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-6 text-center bg-[color:var(--color-paper)]">
      <p className="font-hand text-2xl text-[color:var(--color-accent-warm)] mb-3">
        we looked everywhere in the box
      </p>
      <h1 className="font-display italic text-3xl md:text-4xl text-[color:var(--color-ink)] mb-6">
        This memory doesn&apos;t exist
      </h1>
      <Link
        href="/"
        className="px-6 py-3 rounded-full border border-[color:var(--color-ink)]/20 hover:bg-[color:var(--color-ink)]/5 transition-colors text-sm tracking-wide"
      >
        ← back to the memory box
      </Link>
    </main>
  );
}
