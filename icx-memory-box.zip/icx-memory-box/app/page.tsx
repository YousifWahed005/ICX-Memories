import { getAllEPs, getGeneralMemories } from "@/lib/queries";
import HomeClient from "@/components/memory/HomeClient";

export const revalidate = 30;

export default async function Home() {
  const [eps, memories] = await Promise.all([
    getAllEPs(),
    getGeneralMemories(),
  ]);

  return <HomeClient eps={eps} memories={memories} />;
}
