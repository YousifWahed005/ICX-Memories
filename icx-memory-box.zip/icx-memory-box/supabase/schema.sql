-- ============================================================
-- ICX Digital Memory Box — Supabase schema
-- Run this once in the Supabase SQL editor for your project.
-- ============================================================

create extension if not exists "uuid-ossp";

-- ---------- Tables ----------

create table if not exists ep_profiles (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  country text not null,
  profile_image text not null default '',
  joined_date date not null,
  left_date date not null,
  theme_color text not null default '#2C6E9E',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists ep_photos (
  id uuid primary key default uuid_generate_v4(),
  ep_id uuid not null references ep_profiles(id) on delete cascade,
  image_url text not null,
  caption text,
  photo_date date,
  sort_order integer not null default 0,
  frame_type text not null default 'polaroid',
  rotation numeric not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists general_memories (
  id uuid primary key default uuid_generate_v4(),
  image_url text not null,
  caption text,
  photo_date date,
  sort_order integer not null default 0,
  frame_type text not null default 'polaroid',
  rotation numeric not null default 0,
  featured boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists ep_photos_ep_id_idx on ep_photos(ep_id);
create index if not exists ep_photos_sort_idx on ep_photos(sort_order);
create index if not exists general_memories_sort_idx on general_memories(sort_order);

-- ---------- updated_at trigger ----------

create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists ep_profiles_updated_at on ep_profiles;
create trigger ep_profiles_updated_at
  before update on ep_profiles
  for each row execute function set_updated_at();

-- ---------- Row Level Security ----------
-- Public (anon) can READ everything (this is a public gift site).
-- Only authenticated users (the admin) can INSERT / UPDATE / DELETE.

alter table ep_profiles enable row level security;
alter table ep_photos enable row level security;
alter table general_memories enable row level security;

create policy "Public read ep_profiles" on ep_profiles for select using (true);
create policy "Public read ep_photos" on ep_photos for select using (true);
create policy "Public read general_memories" on general_memories for select using (true);

create policy "Admin write ep_profiles" on ep_profiles
  for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "Admin write ep_photos" on ep_photos
  for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "Admin write general_memories" on general_memories
  for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

-- ---------- Storage ----------
-- Create a public bucket for all memory images.

insert into storage.buckets (id, name, public)
values ('memory-box', 'memory-box', true)
on conflict (id) do nothing;

create policy "Public read memory-box images"
  on storage.objects for select
  using (bucket_id = 'memory-box');

create policy "Admin upload memory-box images"
  on storage.objects for insert
  with check (bucket_id = 'memory-box' and auth.role() = 'authenticated');

create policy "Admin update memory-box images"
  on storage.objects for update
  using (bucket_id = 'memory-box' and auth.role() = 'authenticated');

create policy "Admin delete memory-box images"
  on storage.objects for delete
  using (bucket_id = 'memory-box' and auth.role() = 'authenticated');

-- ============================================================
-- After running this file:
-- 1. Go to Authentication > Users in the Supabase dashboard and
--    create ONE user (your admin email + password). Do not enable
--    public sign-ups anywhere in the app.
-- 2. Copy your Project URL and anon public key into .env.local
--    (see .env.example).
-- ============================================================
