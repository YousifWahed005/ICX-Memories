-- ============================================================
-- Sample dummy data — run AFTER schema.sql.
-- Uses placeholder images (picsum.photos) so the site looks
-- complete before you upload real photos through /admin.
-- Safe to delete all rows from these 3 tables later and start fresh.
-- ============================================================

do $$
declare
  ep1 uuid; ep2 uuid; ep3 uuid; ep4 uuid; ep5 uuid;
begin

insert into ep_profiles (name, country, profile_image, joined_date, left_date, theme_color)
values ('Amara Okafor', 'Nigeria', 'https://picsum.photos/seed/amara/600/600', '2026-01-12', '2026-03-02', '#D97A4E')
returning id into ep1;

insert into ep_profiles (name, country, profile_image, joined_date, left_date, theme_color)
values ('Luca Moretti', 'Italy', 'https://picsum.photos/seed/luca/600/600', '2026-02-01', '2026-03-20', '#2C6E9E')
returning id into ep2;

insert into ep_profiles (name, country, profile_image, joined_date, left_date, theme_color)
values ('Aiko Tanaka', 'Japan', 'https://picsum.photos/seed/aiko/600/600', '2026-03-05', '2026-04-25', '#7A9E5E')
returning id into ep3;

insert into ep_profiles (name, country, profile_image, joined_date, left_date, theme_color)
values ('Diego Fernández', 'Mexico', 'https://picsum.photos/seed/diego/600/600', '2026-04-10', '2026-05-30', '#B5546E')
returning id into ep4;

insert into ep_profiles (name, country, profile_image, joined_date, left_date, theme_color)
values ('Zara Khan', 'Pakistan', 'https://picsum.photos/seed/zara/600/600', '2026-05-01', '2026-06-18', '#C99A2E')
returning id into ep5;

insert into ep_photos (ep_id, image_url, caption, photo_date, sort_order, frame_type, rotation) values
(ep1, 'https://picsum.photos/seed/amara1/800/1000', 'First day at the office', '2026-01-13', 0, 'polaroid', -4),
(ep1, 'https://picsum.photos/seed/amara2/1000/700', 'Suez Canal walk', '2026-01-20', 1, 'taped', 3),
(ep1, 'https://picsum.photos/seed/amara3/800/800', 'Team lunch', '2026-02-02', 2, 'rotated-card', -2),
(ep1, 'https://picsum.photos/seed/amara4/700/1000', 'Farewell hug', '2026-03-01', 3, 'polaroid', 5);

insert into ep_photos (ep_id, image_url, caption, photo_date, sort_order, frame_type, rotation) values
(ep2, 'https://picsum.photos/seed/luca1/800/1000', 'Arrival at Cairo airport', '2026-02-01', 0, 'polaroid', 4),
(ep2, 'https://picsum.photos/seed/luca2/1000/700', 'Global Village rehearsal', '2026-02-15', 1, 'taped', -3),
(ep2, 'https://picsum.photos/seed/luca3/800/800', 'Beach day', '2026-03-01', 2, 'rotated-card', 2);

insert into ep_photos (ep_id, image_url, caption, photo_date, sort_order, frame_type, rotation) values
(ep3, 'https://picsum.photos/seed/aiko1/800/1000', 'Welcome dinner', '2026-03-06', 0, 'polaroid', -3),
(ep3, 'https://picsum.photos/seed/aiko2/1000/700', 'Workshop day', '2026-03-20', 1, 'taped', 4),
(ep3, 'https://picsum.photos/seed/aiko3/700/1000', 'Sunset at the office rooftop', '2026-04-10', 2, 'polaroid', -5),
(ep3, 'https://picsum.photos/seed/aiko4/800/800', 'Last dinner together', '2026-04-24', 3, 'rotated-card', 3);

insert into ep_photos (ep_id, image_url, caption, photo_date, sort_order, frame_type, rotation) values
(ep4, 'https://picsum.photos/seed/diego1/800/1000', 'First week jitters', '2026-04-11', 0, 'polaroid', 3),
(ep4, 'https://picsum.photos/seed/diego2/1000/700', 'City tour', '2026-04-25', 1, 'taped', -4),
(ep4, 'https://picsum.photos/seed/diego3/800/800', 'Karaoke night', '2026-05-10', 2, 'rotated-card', 2);

insert into ep_photos (ep_id, image_url, caption, photo_date, sort_order, frame_type, rotation) values
(ep5, 'https://picsum.photos/seed/zara1/800/1000', 'Orientation day', '2026-05-02', 0, 'polaroid', -2),
(ep5, 'https://picsum.photos/seed/zara2/1000/700', 'AIESEC family photo', '2026-05-20', 1, 'taped', 3),
(ep5, 'https://picsum.photos/seed/zara3/700/1000', 'Last goodbye at the airport', '2026-06-18', 2, 'polaroid', -4);

insert into general_memories (image_url, caption, photo_date, sort_order, frame_type, rotation, featured) values
('https://picsum.photos/seed/gen1/1200/800', 'Whole ICX family, day one', '2026-01-14', 0, 'taped', -3, true),
('https://picsum.photos/seed/gen2/900/1200', 'Global Village Suez 2026', '2026-05-22', 1, 'polaroid', 4, true),
('https://picsum.photos/seed/gen3/1000/700', 'Office game night', '2026-02-10', 2, 'rotated-card', -2, false),
('https://picsum.photos/seed/gen4/700/1000', 'Suez sunrise trip', '2026-02-27', 3, 'polaroid', 3, false),
('https://picsum.photos/seed/gen5/1000/1000', 'Cultural night dance-off', '2026-03-18', 4, 'taped', -4, true),
('https://picsum.photos/seed/gen6/1100/750', 'Impact circle closing', '2026-04-05', 5, 'rotated-card', 2, false),
('https://picsum.photos/seed/gen7/800/1100', 'Boat trip on the canal', '2026-04-19', 6, 'polaroid', -3, false),
('https://picsum.photos/seed/gen8/1000/700', 'Farewell bonfire', '2026-06-20', 7, 'taped', 3, true),
('https://picsum.photos/seed/gen9/900/900', 'Team building day', '2026-03-08', 8, 'rotated-card', -5, false),
('https://picsum.photos/seed/gen10/1000/1300', 'Everyone, one last time', '2026-06-25', 9, 'polaroid', 2, true),
('https://picsum.photos/seed/gen11/1000/700', 'Office decoration day', '2026-01-30', 10, 'taped', -2, false),
('https://picsum.photos/seed/gen12/850/1050', 'Random Tuesday laughs', '2026-04-02', 11, 'rotated-card', 4, false);

end $$;
